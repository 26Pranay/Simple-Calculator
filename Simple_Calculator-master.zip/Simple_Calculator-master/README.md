Developed a Simple to do webpage using HTML,CSS& Js
